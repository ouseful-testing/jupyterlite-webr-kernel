#' A function to calculate a log-likelihood
#'
#' @param p the binomial probability
#' @param y the data (a vector of zeros and ones
#'
#' @return the value of the log-likelihood
#'
#' @author Karen Vines
#' 
#' @export


logLik <- function(p, y){
	n <- length(y)
	sy <- sum(y)
	value <- sy*log(p) + (n-sy)*log(1-p)
	value
}
