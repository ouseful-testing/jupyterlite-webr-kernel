.onLoad <- function(libname, pkgname){
	if (exists("PORTNUMBER")){
		initialise(PORTNUMBER = PORTNUMBER)
	} else {
		initialise()
	}
}	
