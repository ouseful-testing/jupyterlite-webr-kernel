#' Childhood obesity
#'
#' These data were collected through the National Child Measurement Programme (NCMP), and a child is defined as obese based on
#' their BMI measurement. These data relate to the years 2020 and 2021.
#'
#' @format A data frame with 16 rows and 6 variables:
#' \describe{
#'   \item{deprivation}{the index of multiple deprivation (IMD), taking the values most and least}
#'   \item{gender}{the gender the child identifies with, taking the coded values 0 (for male) and 1 (for female)}
#'   \item{ageGroup}{the age group the child is in, taking the coded values 1 (for 4 to 5 year olds) and 2 (for 10 to 11 year olds),}
#'   \item{countYes}{the number of obese children in the corresponding category}
#'   \item{countNo}{the number of  children who are not obese corresponding category}
#' }
#'
#' @usage data(ncmpManipulated)

"ncmpManipulated"
