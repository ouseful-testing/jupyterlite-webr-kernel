#' A function to perform Newton-Raphson for a binomial likelihood
#'
#' @param p0 the initial guess for the binomial probability
#' @param y a vector or zeros and ones
#' @param epsilon the tolerance for the function
#' @param maxIter the maximum number of iterations permitted
#'
#' @return the estimate of the binomial probability
#'
#' @author Karen Vines
#' 
#' @export


nRaph <- function(p0,y=y, epsilon = 0.0001, maxIter=100){
	pOld <- p0
	n <- length(y)
	sy <- sum(y)
	for(k in 1:maxIter){
		pNew <- pOld - lDash(pOld,n,sy)/lDoubleDash(pOld,n,sy)
		if (abs(pNew-pOld)< epsilon){
			cat("Estimated MLE of p is", pNew, "found in",k,"iterations.\n")
			break
		}
		pOld <- pNew
	}
	if (k == maxIter) cat("Too many iterations performed but estimate not found.\n")

}

