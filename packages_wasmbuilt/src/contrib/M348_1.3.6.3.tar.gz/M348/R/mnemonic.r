#' Effectiveness of methods to improve memory
#'
#' In a study,researchers collected data on different ways to improve memory. 
#' Two mnemonic methods for trying to improve verbal recall are the Galton's walk method 
#' (Mnemonic A) and the peg method (Mnemonic B). Thirty participants were randomly 
#' assigned to one of three equal-sized groups:
#' \itemize{
#' \item A group trained to use Mnemonic A (group A).
#' \item A group trained to use Mnemonic B (group B).
#' \item A control group, which received no training (group C).
#' }
#' Each participant was presented with verbal material and at a later stage was asked to 
#' reproduce it in free written recall. In the data file, the first column (\code{count}) 
#' gives the number of words recalled by a participant and the second column 
#' (\code{group}) gives the participant's group.
#'
#' @format A data frame with 30 rows and 2 variables:
#' \describe{
#'   \item{count}{number of words recalled by a participant (response)}
#'   \item{group}{participant's group (A, B, C)}
#' }
#'
#' @source Kinnear, P. R. and Gray, C. D. (1996). 
#' \emph{SPSS for Windows Made Simple}, Hove, \emph{Psychology Press.})
#'
#' @usage data(mnemonic)

"mnemonic"
