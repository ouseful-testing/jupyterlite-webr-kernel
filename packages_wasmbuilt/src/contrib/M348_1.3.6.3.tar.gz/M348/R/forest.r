#' Population pressures on forests
#'
#' This is a cross sectional dataset with observations collected for 70 tropical countries.
#'
#' @format A data frame with 101 rows and 4 variables:
#' \describe{
#'   \item{forestLoss}{deforestation (in percentages) over the period 1981-1990}
#'   \item{popDens}{population density (number of people per 1000 hectare) in 1990}
#'   \item{cropCh}{percentage change in cropland over the period 1981-1990}
#'   \item{pastureCh}{percentage change in pasture land over the period 1981-1990}
#' }
#'
#' @source Koop, G. (2005) Analysis of Economic data. 2nd edition.Chichester: John Wiley and Sons Ltd.

#' @usage data(forest)

"forest"
