#' A function to initalise the Jupyterlite environment
#'
#' @param PORTNUMBER which port is begin used
#'
#' @return Nothing
#'
#' @author Karen Vines
#' 
#' @export


initialise <- function(PORTNUMBER = 8348){
	options(device = .plotdevice, web.plot.new=FALSE)
	PORTNUMBER <<- PORTNUMBER
#	cat("The port number is ", PORTNUMBER,"\n")
}
