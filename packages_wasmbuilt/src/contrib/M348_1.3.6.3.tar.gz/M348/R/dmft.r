#' Oral health of children 
#'
#' In the Belo Horizonte Caries Prevention (BELCAP) study, the effectiveness
#' of different interventions for oral health in children was compared. A total
#' of 797 children (all of whom were 7 years old at the beginning of the study)
#' were recruited. They were then given one of six different treatments (one of
#' four interventions, all four interventions together or none of the
#' interventions). Children in the same school received the same treatment
#'
#' @format A data frame with 797 rows and 3 variables:
#' \describe{
#'   \item{startDMFT}{the child's DMFT value at the beginning of the study}
#'   \item{treat}{the treatment given to the child}
#'   \item{endDMFT}{the child's DMFT value at the end of the study}
#' }
#'
#' @usage data(dmft)

"dmft"
