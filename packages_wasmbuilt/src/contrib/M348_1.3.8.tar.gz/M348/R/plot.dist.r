#' A plot function for dist objects
#'
#' A function to produce plots of dissimilarity matrices. It assumes that the input is in the 
#' form of a dist object (produced by the function dist()). There is the option to order the 
#' data points by a clusters given by a clustering algorithm.
#'
#' @param  distobj the dist object to be plotted
#' @param  clusters a vector giving the cluster allocation for the data points used to create distobj
#' @param names a vector giving the names of the clusters
#' @param  max.dist a value giving the assumed maximum dissimilarity in the matrix
#'
#' @return A plot of the dissimilarity matrix.
#'
#' @author Karen Vines
#'
#' @seealso See also \code{\link{dist}}.
#'
#' @keywords plot 
#'
#' @examples
#' X <- c(10,8,9,2,5,0)
#' distX <- dist(X)
#' # Plot of the dissimilarity matrix
#' dissimPlot(distX)
#' # Plot of the dissimilarity ordering by cluster
#' dissimPlot(distX, clusters=c(1,1,1,2,2,2))
#'
#' @export



dissimPlot<- function(distobj, clusters=NULL, names = NULL, max.dist = NULL){

	npts <- attributes(distobj)$Size
	if (is.null(names)){
		if (is.null(clusters)) {
			names <- c(1:npts)
			namepos <- c(1:npts)

		} else {
			names <- unique(sort(clusters))
			namepos <- unique(rank(sort(clusters)))
		}
	} else {
		namepos <- c(1:length(names))
	}


	if (!is.null(clusters)){
		if (length(clusters) != npts){
			cat("Length of cluster allocation does not match the number of data points\n")
			stop()
		}
		ord <- order(clusters)
		ord[ord] <- c(1:npts)
		if (length(names)== npts){
			names[ord] <- names
		}
	} else {
		ord <- c(1:npts)
	}

	dlo <- 0
	if (is.null(max.dist)){
		dhi <- max(distobj)
	} else {
		dhi <- max.dist
		if (dhi < max(distobj)){
			cat("Warning: given maximum dissimilarity (max.dist = ",max.dist,") is less then the actual maximum dissimilarity (",max(distobj),")\n")
		}
	}

	M348red<- "#a92021"
	ncols <- 100
# 	Create vector of color codes
	redpalette <- rep(M348red,ncols)
	alphas <- seq(0,1,length.out = (ncols+1))                   

	for(i in 1:(ncols+1)) {
  		redpalette[i] <- grDevices::adjustcolor(M348red, alpha.f = (i-1) / ncols)
	}

	dmat <- as.matrix(distobj)
	dmat[ord,] <- dmat
	dmat[,ord] <- dmat
	dmat <- dmat[,1+npts-c(1:npts)]

	par(pty="s")
	graphics::image(x=c(1:npts), y=c(1:npts), z=dmat,zlim=c(dlo,dhi), col=redpalette,pty="s", xlab="",ylab="",xaxt="n",yaxt="n",xaxs="i",yaxs="i",useRaster=TRUE)
	graphics::axis(3,at=namepos,labels=names,tck=0)
	graphics::axis(2,at=(1+npts-namepos),labels=names,tck=0)


	graphics::axis(1,at=c(0,(npts+1)),labels=c("",""),tck=0)
	graphics::axis(4,at=c(0,(npts+1)),labels=c("",""),tck=0)


	if (!is.null(clusters)){
		nclus <- table(clusters)
		nclus <- cumsum(nclus)
		nclus <- nclus[-length(nclus)]
		graphics::abline(v=nclus+0.5,lty=2,lwd=2)
		graphics::abline(h=npts-nclus+0.5,lty=2,lwd=2)
	}
}